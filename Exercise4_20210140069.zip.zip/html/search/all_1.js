var searchData=
[
  ['kartukeluarga_0',['Kartukeluarga',['../class_i_p_k_1_1_kartukeluarga.html',1,'IPK']]]
];
